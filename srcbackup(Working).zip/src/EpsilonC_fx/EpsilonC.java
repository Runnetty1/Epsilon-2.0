/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EpsilonC_fx;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.*;
import javafx.application.Application;
import javafx.event.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.*;
import javafx.util.Duration;
import javax.crypto.KeyGenerator;

/**
 *
 * @author Runnetty
 */
public class EpsilonC extends Application {

    @Override
    public void start(final Stage stage) throws Exception {
        // load the scene fxml UI.
        // grabs the UI scenegraph view from the loader.
        // grabs the UI controller for the view from the loader.
        final FXMLLoader loader = new FXMLLoader(getClass().getResource("lol.fxml"));
        final Parent root = (Parent) loader.load();
        final FXMLDocumentController controller = loader.<FXMLDocumentController>getController();

        TreeLoadingEventHandler treeLoadingEventHandler = new TreeLoadingEventHandler(controller);

        //Timer for security check
        /*final Timeline timeline = new Timeline(
         new KeyFrame(
         Duration.seconds(3),
         new SecurityCheckEventHandler()
         )
         );
         timeline.setCycleCount(Timeline.INDEFINITE);
         timeline.play();
         */
        // initialize the stage.
        Scene scene = new Scene(root);
        scene.setFill(null);
        //scene.getStylesheets().add("css.css");
        stage.setScene(scene);
        stage.initStyle(StageStyle.DECORATED);

        stage.setScene(scene);
        //stage.getIcons().add(new Image(getClass().getResourceAsStream("myIcon.png")));
        generatekey();
        stage.show();

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    private void generatekey() {
        FileHandler fh = new FileHandler();
        if (!new File(fh.getDefaultFilePath() + fh.sep + "NodeInfo" + fh.sep + "key.bin").exists()) {
            try {
                System.out.println("\nStart generating DES key");
                
                KeyGenerator keyGen = KeyGenerator.getInstance("DES");
                keyGen.init(56);
                Key key = keyGen.generateKey();
                System.out.println("Finish generating DES key");
                byte[] keyAsByte = key.getEncoded();
                FileOutputStream keyfos = new FileOutputStream(fh.getDefaultFilePath() + fh.sep + "NodeInfo" + fh.sep + "key.bin");
                keyfos.write(keyAsByte);
                keyfos.close();
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(EpsilonC.class.getName()).log(Level.SEVERE, null, ex);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(EpsilonC.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(EpsilonC.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
