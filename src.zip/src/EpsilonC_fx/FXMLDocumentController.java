/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EpsilonC_fx;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javax.swing.tree.DefaultMutableTreeNode;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Runnetty
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private TreeView<String> locationTreeView;

    private TreeItem<String> root;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadTreeItems();
    }

    // loads some strings into the tree in the application UI.
    public void close(){
        System.exit(0);
    }
    public void loadTreeItems() {
         XMLReader reader = new XMLReader();
        System.out.println("Loading treeitems");
        try {
            root = new TreeItem<String>(reader.getTreeRoot());
            root.setExpanded(true);
            root.getChildren().add(
                    nodesfromXMLDoc(reader.getXMLDoc().getDocumentElement())
            );

            locationTreeView.setRoot(root);
            locationTreeView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        locationTreeView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                
                TreeItem treeItem = (TreeItem)newValue;
                System.out.println("Selected item is " + treeItem.getValue());
                //Open the file and show in text area
                

            }   
        });
        } catch (Exception exc) {
            System.out.println("Error: " + exc.getMessage());
        }
    }

    public TreeItem nodesfromXMLDoc(Node node) {
       
        
        //System.out.println(node.getNodeName());
        TreeItem<String> a = new TreeItem<String>(node.getNodeName());
        NodeList nodeList = node.getChildNodes();

        if (1 > nodeList.getLength()) {
            //System.out.println("This is a end branch so add the node to root");
            a.setValue(a.getValue());
        }

        for (int i = 0; i < nodeList.getLength(); i++) {
            Node currentNode = nodeList.item(i);
            if (currentNode.getNodeType() == Node.ELEMENT_NODE) {
                //calls this method for all the children which is Element
                a.getChildren().add(nodesfromXMLDoc(currentNode));
            }
        }
        return a;
    }
    
}
