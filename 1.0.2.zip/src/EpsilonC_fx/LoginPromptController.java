/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EpsilonC_fx;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.*;
import javafx.scene.control.*;
import javafx.stage.StageStyle;

/**
 *
 * @author Runnetty
 */
public class LoginPromptController implements Initializable {

    private String username = "Drift";
    private String password = "Beta486";

    @FXML
    private PasswordField passwordField;
    @FXML
    private TextField usernameField;
    @FXML
    private Button loginButton;
    @FXML
    private Button UpdateButton;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        UpdateCheck u = new UpdateCheck();
        if(u.serverHasNewerVersion()){
            u.getUpdate();
        }
    }
    @FXML
    public void loginAttempt() {
        if (usernameField.getText().equalsIgnoreCase(username) && passwordField.getText().equalsIgnoreCase(password)) {
            System.out.println("OK Login In");
           
            Stage s = new Stage();
            startMainWindow(s);
        }
    }
    public void close() {
        System.exit(0);
    }
    public void startMainWindow(final Stage stage) {
        try {
            // load the scene fxml UI.
            // grabs the UI scenegraph view from the loader.
            // grabs the UI controller for the view from the loader.
            final FXMLLoader loader = new FXMLLoader(getClass().getResource("MainWindow.fxml"));
            final Parent root = (Parent) loader.load();
            final MainWindowController controller = loader.<MainWindowController>getController();

            TreeLoadingEventHandler treeLoadingEventHandler = new TreeLoadingEventHandler(controller);

            //Timer for security check
            /*final Timeline timeline = new Timeline(
             new KeyFrame(
             Duration.seconds(3),
             new SecurityCheckEventHandler()
             )
             );
             timeline.setCycleCount(Timeline.INDEFINITE);
             timeline.play();
             */
            // initialize the stage.
            Scene scene = new Scene(root);
            scene.setFill(null);

            //scene.getStylesheets().add("css.css");
            stage.setScene(scene);
            stage.initStyle(StageStyle.DECORATED);
            stage.setTitle("Epsilon C");
            stage.setScene(scene);
            //stage.getIcons().add(new Image(getClass().getResourceAsStream("myIcon.png")));
            Safety s = new Safety();
            s.generatekey();
            stage.show();
            Stage stage1 = (Stage) loginButton.getScene().getWindow();
            stage1.close();
        } catch (IOException ex) {
            Logger.getLogger(LoginPromptController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
